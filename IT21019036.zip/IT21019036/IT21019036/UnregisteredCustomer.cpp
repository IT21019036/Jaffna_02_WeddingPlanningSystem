#include "Unregisteredcustomer.h"
#include<iostream>
#include<cstring>

UnregisteredCustomer::UnregisteredCustomer()
{
}

UnregisteredCustomer::UnregisteredCustomer(const char Name[], int ID, string Location, string Email, int Age, string DoB, const char Gender[], int Contact)
{
	strcpy_s(uName, Name);
	uLocation = Location;
	uEmail = Email;
	uAge = Age;
	uDoB = DoB;
	strcpy_s(uGender, Gender);
	uContact = Contact;
}

void UnregisteredCustomer::display_uDetails()
{
}
