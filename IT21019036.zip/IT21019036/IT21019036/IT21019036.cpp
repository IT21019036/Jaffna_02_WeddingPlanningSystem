#include <iostream>
#include "Unregisteredcustomer.h"
#include "Hall.h"


int main()
{

    UnregisteredCustomer Urc1;
    Urc1.display_uDetails();

    Hall Ha1;
    Ha1.display_haDetails();
}
