#pragma once
class Hall
{
private:
	char haName[30];
	int  haId;
	int  harCustomerId;

public:
	Hall();
	Hall(const char Name[], int ID, int CustomerID);
	void assingn_haDetails();
	void display_haDetails();

};

