#include "Hall.h"
#include<iostream>
#include<cstring>

Hall::Hall()
{
}

Hall::Hall(const char Name[], int ID, int CustomerID)
{
	strcpy(haName, Name);
	haId = ID;
	harCustomerId = CustomerID;
}

void Hall::assingn_haDetails()
{
}

void Hall::display_haDetails()
{
}
