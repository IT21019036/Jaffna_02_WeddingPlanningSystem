#include<iostream>
#include<cstring>
using namespace std;

class UnregisteredCustomer
{
private:
	char   uName[50];
	string uLocation;
	string uEmail;
	int    uAge;
	string uDoB;
	char   uGender[15];
	int    uContact;
public:
	UnregisteredCustomer();
	UnregisteredCustomer(const char Name[], int ID, string Location, string Email, int Age, string DoB, const char Gender[], int Contact);
	void display_uDetails();

};

